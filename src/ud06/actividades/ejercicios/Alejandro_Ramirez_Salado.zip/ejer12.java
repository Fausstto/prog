package ud06.actividades.ejercicios;

public class ejer12 {
}
