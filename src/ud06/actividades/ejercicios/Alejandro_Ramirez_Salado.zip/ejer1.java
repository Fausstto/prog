package ud06.actividades.ejercicios;
//Desarrolla una aplicación que cree un vector con los números 4, 5, 6, 7 y lo muestre por
//pantalla.
public class ejer1 {
    public static void main(String[] args) {
        int[] vector={4,5,6,7};
        for(int i:vector){
            System.out.println(i);
        }
    }
}
